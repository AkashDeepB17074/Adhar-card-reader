var express = require('express');
var bcrypt = require('bcryptjs')
var jwt = require('jsonwebtoken')
var multer = require('multer')
var path = require('path')
const {check, validationResult} = require("express-validator")
var userModel = require('../modules/users')
var error_box = require('../modules/error')


if(typeof localStorage === "undefined" || localStorage == null){
  var LocalStorage = require('node-localstorage').LocalStorage
  localStorage = new LocalStorage('../scratch')
}


var router = express.Router();

/* GET home page. */

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Stock Manager', heading: "Stock Management System" });
});
console.log(__filename)


//  Sign Up things //
router.get('/signup', function(req, res, next){
  var loginUser = localStorage.getItem('loginUser')
  if(loginUser){
    res.redirect('/viewall')
  }else{
    res.render('signup', {title: "GET_Signup", error: new error_box()})
  }
})
var usernameValidation = function(req, res, next){
  var usr = req.body.username
  var checkExist = userModel.findOne({username: usr})
  checkExist.exec(function(err, data){
    if (err) throw err
    if (data){
      var error = new error_box(2, "Username Already Exists Try Another !")
      return res.render('signup', {title: "Validation", error: error})
    }
    next()
  })
}

var emailValidation = function(req, res, next){
  var eid = req.body.email.toLowerCase()
  userModel.findOne({email: eid}, function(err, data){
    if (err) throw err
    if(data){  
      error = new error_box(2, "Email Address Already Exists Try Another !")
      console.log('Validatioin Completed  Email Does Already Exist!')
      return res.render('signup', {title:"Validation", error:error})
    }
    next()
  })
}
// var userValidation = function(req, res, next){
//   var usr = req.body.username
//   var eid = req.body.email
//   let checkExistEmail = userModel.findOne({email: eid})
//   let checkExistUsername = userModel.findOne({username: usr})
//   let msg = {email: "", username: ""};
//   checkExistEmail.exec(function(err, data){
//     checkExistUsername.exec(function(err, data){
//       if (err) throw err
//       if(data){
//         msg.username = "Username Already Exists"
//       }
//     })
//     if (err) throw err;
//     if(data){
//       msg.email = "Email Already Exists"
//     }
//     if(msg.username !="" || msg.email!=""){
//       res.render('signup', {title:"Validation Signup", msg: msg})
//     }
//     next()
//   })
// }

router.post('/signup', usernameValidation, emailValidation,
            [check('email', 'Enter Valid Email Address').isEmail(), 
             check('password', 'Password Should Contain Atleast 5 chars').isLength({min:5})],
            /*userValidation,
            [check('username', "Username should be of length > 1").isLength({min: 1}),
             check('email', "not a valid email id ").isEmail(), 
             check('password', "password must be greater than 8 digit").isLength({min:8})],*/
            function(req, res, next){
  console.log("############ SIGN UP POST #############")
  console.log(req.body)
  var tou = req.body.typeofuser
  var usrN = req.body.username
  var eid = req.body.email.toLowerCase()
  var pass = req.body.password
  var cpass = req.body.confirmpassword
  console.log('Condition Check' , usrN, eid, pass,((usrN == "") || (eid =="" || pass=="") ))
  
  const errors = validationResult(req);
  console.log('error mapped ==> ', errors.mapped())
  if(!errors.isEmpty()){
    msgs = ''
    error = new error_box()
    if(errors.mapped().email)
      msgs = msgs + errors.mapped().email.msg 
    if(errors.mapped().password)
      msgs = msgs +"\n" +errors.mapped().password
    error.setType(3)
    error.msg = msgs
    res.render('signup', {title:"emailPass Validator", error:error})
  }
  else if((usrN == "") || (eid == "" || pass=="")){
    console.log('## [{ FILL ALL FIELDS }] ##')
    error = new error_box(2, "Please Fill All the required fields !")
    res.render('signup', {title: "fillfield",error: error})
  }
  else if(pass != cpass){
    console.log('## [{ PASSWORD NOT MATCHED }] ##')
    error = new error_box(2, "Password Do Not Match !")
    res.render('signup', {title:"PassMatch", error:error})
  }else{
  pass = bcrypt.hashSync(pass, 10);
  console.log("user Model => ",userModel)
  var user = new userModel({
    typeOfUser: tou,
    username: usrN, 
    email: eid, 
    password: pass
  })

  // console.log(user)
  user.save((err, data)=>{
    if(err) throw err
    console.log(data)
    console.log("## [{ SAVED! }] ##")
    // res.redirect('login')
    error = new error_box(0, "Your New User Added Successfully")
    error.setRedirectingPage('login', "Login Now")
    error.setActionValue('Add More')
    res.render('signup', {title: "POST_SIGNUP", error: error})
  })
  }
})
///////////////////////////////////////////~

// ################### TOKEN STORAGE WHICH WILL BE VERIFIED IN EVERYPAGE ###########

router.get('/login', (req, res, next)=>{
   var loginUser = localStorage.getItem('loginUser')
   if(loginUser){
      res.redirect('/viewall')
    }else{
      console.log('Redirected to login get')
      res.render('login', {title: 'Login Form', error:new error_box(), heading:'Stock Manager'})
    }
})

router.post('/login', (req, res, next)=>{
  console.log("redirected to login post")
  var eid = req.body.email.toLowerCase();
  var pass = req.body.password; 
  var tou = req.body.typeofuser
  console.log('email :: ', eid)
  console.log('userModel :: ', userModel)
  var checkUser = userModel.findOne({email: eid.toLowerCase()})
  checkUser.exec((err, data)=>{
    if (err) throw err
    console.log("data  :: ",  data)
    console.log("paaaaaas  :: ", pass)
    if(data){
    if(data.accountVerification(pass)){
      var token = jwt.sign({email: eid}, 'loginTokenOfEmail')
      localStorage.setItem('loginToken', token)
      localStorage.setItem('loginUser', eid)
      console.log('## [{ USER VEREFIED }] ##')
      res.redirect('/viewall')
    }else{
      error = new error_box(3,"Password Is Incorrect !")
      res.render('login', {title: 'Login Form', heading:'Stock Manager', error:error})
    }
    }else{
      error = new error_box(3,"Unable To Login !")
      res.render('login', {title: 'Login Form', heading:'Stock Manager', error:error})
    }
  })
})
/////////////////////////////

function checkUserLoggedIn(req, res, next){
  var getToken = localStorage.getItem('loginToken')
  try{
    var decoded = jwt.verify(getToken, 'loginTokenOfEmail')
  }catch(err){
    console.log("## [{ USER VALIDATION FAILED }] ##")
    return res.redirect('login')
  }
  next()
}

router.get('/viewall', checkUserLoggedIn, function(req, res, next){
  let loginUserId = localStorage.getItem('loginUser')
  userModel.findOne({email:loginUserId}, (err, data)=>{
    if (err) throw err
    if (data){
      if(data.typeOfUser == "Admin")
        var Data = stockModel.find({})
      else
        var Data = stockModel.find({username:loginUserId})
        console.log("loginUserId ==> ", loginUserId)
      Data.exec(function(err, data){
        if(err) throw err
        if(data){
          // console.log("Data found ==> ", data)
          res.render('viewall', {error: new error_box(), data: data})
        }else{
          console.log("## [{ DATA NOT FOUND ! }] ##")
          error = new error_box(3, "Unable To Find Any Data !")
          res.render('viewall', {error:error, data: data})
        }
      })
    }
  })
  console.log('Redirecting to viewall get')
})

router.get('/logout', function(req, res, next){
  localStorage.removeItem('loginUser')
  localStorage.removeItem('loginToken')
  console.log('logged out from sessions')
  res.redirect('/login')
})





// ########## ADD AND EDIT PASS ##############//
router.get('/addnew', checkUserLoggedIn, function(req, res, next){
  console.log('Redirected To Add New Stock')
  res.render('addnew', {title: "AddNew Stock", error: new error_box()})
})
// router.get('/edit', checkUserLoggedIn, function(req, res, next){
//   console.log('Redirected To Add New Stock')
//   res.render('edit', {title: "edit Stock", msg:""})
// })



var stockModel = require('../modules/stockschema')
var fs = require('fs')
// ###################### ADD AND EDIT POST METHODS ################################
// var multer = require('multer')
var Storage = multer.diskStorage({
  destination: './public/candidate', 
  filename: (req, file, cb)=>{
    console.log("fileName saved as ==> ", file.fieldname+"_"+Date.now()+"_"+path.extname(file.originalname))
    cb(null, file.fieldname+"_"+Date.now()+"_"+path.extname(file.originalname))
  }
})
var upload = multer({
  storage: Storage
}).single('input_file')

router.post('/addnew', checkUserLoggedIn, upload, function(req, res, next){
  console.log("user added information ")
  console.log("ADD new post req body ", req.body)
  console.log("Add nwe post req file", req.file)
  imgPath = null
  if (req.file)
    imgPath = req.file.filename
  console.log("condition ==> ", (req.body.weblink==""||(req.body.password==""||req.body.email=="")))
  if( req.body.weblink==""||(req.body.password==""||req.body.email=="")){
    console.log("rendering addnew right now")
    var error = new error_box(3, "Fill All Ther Required Fields !")
    res.render('addnew', {title:"AddNew", error: error})
  }
  else{
  var stock = new stockModel({
    username: localStorage.getItem('loginUser'),
    name: req.body.name,
    imagePath: imgPath, 
    weblink: req.body.weblink,
    email: req.body.email.toLowerCase(),
    password: req.body.password,
    password_type: req.body.passwordtype,
    description: req.body.description
  })
  stock.save(function(err, data){
    if(err) throw err
    console.log("## IN SAVE METHOD ##")
    var error = new error_box(0, "Successfully Added Users !")
    error.setRedirectingPage('viewall', 'VIEW ALL')
    error.setActionValue('ADD MORE')
    res.render('addnew', {title: "Addnew Saved!", error: error})
  })}
})

// ###################### Edit POST METHOD ##############
router.get('/edit/:Id?', checkUserLoggedIn, (req, res, next)=>{
  console.log(req.params)
  // res.json({text:'lorem launda'})
  stockModel.findOne({$and: [{username: localStorage.getItem('loginUser')}, {_id: req.params.Id}]}, function(err, data){
    if(err) throw err
    // console.log("Data found no need to worry ", data)
    if(data)
      res.render('edit', {title: "Edit Stock", error: new error_box(), data: data})
    else
      res.render('edit', {title:"Edit Stock",error:new error_box(1,"First Select Something To edit"), data:{}})
  })
})

router.post('/viewall/:Id?', checkUserLoggedIn, upload, (req, res, next)=>{
  // console.log("edit post Id", req.params)
  // console.log('edit post body ', req.body)
  // console.log('edit post file ', req.file)
  stockModel.findOne({$and: [{username: localStorage.getItem('loginUser')}, {_id: req.params.Id}]}, function(err, data){
    if(err) throw err
    if(data){
      if(req.file && fs.existsSync('./public/candidate/'+data.imagePath)){
        fs.unlink('./public/candidate/'+data.imagePath, function(err){
          if(err) throw err
          console.log("Successfully Deleted old image file")
        })
      }

      var toUpdate = {
        name: req.body.name,
        imagePath: (req.file)?req.file.filename:data.imagePath,
        email: (req.body.email=="")?data.email:req.body.email.toLowerCase(), 
        password: (req.body.password=="")?data.password:req.body.password, 
        weblink: (req.body.weblink=="")?data.weblink:req.body.weblink, 
        password_type: req.body.passwordtype, 
          description: req.body.description 
      }
      stockModel.findOneAndUpdate({$and: [{username: localStorage.getItem('loginUser')}, {_id: req.params.Id}]},{$set: toUpdate}).exec(function(err, data){
        if(err) throw err
        if(data)
        console.log("\n## [{ DATA SAVED SUCCESSFULLY !  }] ##\n", data)
        res.redirect('/viewall')
        // res.render('viewall', { msg: "updated Successfully",Data:[]})
      })
    }
  })
})


// ############################# DELETING ############################
router.get('/delete/:Id?', checkUserLoggedIn, function(req, res, next){
  stockModel.findOneAndRemove({$and: [{username: localStorage.getItem('loginUser')}, {_id:req.params.Id}]}, (err, data)=>{
    if(err) throw err
    if(fs.existsSync('./public/candidate/'+data.imagePath)){
      fs.unlink('./public/candidate/'+data.imagePath, function(err){
        if(err) throw err
        console.log("Deleted Image file")
      })
    }
    if(data)
    console.log("\n## [{ DATA DELETED SUCCESSFULLY }] ##\n", data)
    res.redirect('/viewall')
  })
})


var searchModel = require('../modules/searchSchema')
// ###################################### SEARCH #############################
router.get('/:searchBy/:search', checkUserLoggedIn, (req, res, next)=>{
  console.log(req.params)
  const localUser = localStorage.getItem('loginUser')
  if(req.params.searchBy == "name")
  var result = stockModel.find({$and: [{username: localUser}, {name: req.params.search}]})
  else if(req.params.searchBy == "email")
  var result = stockModel.find({$and: [{username: localUser}, {email: req.params.search.toLowerCase()}]})
  else if(req.params.searchBy == "password")
  var result = stockModel.find({$and: [{username: localUser}, {password: req.params.search}]})
  result.exec(function(err, data){
    if (err) throw err
    console.log(data, typeof(data), data.length)
    if(data.length){
      // var search = new searchModel({
      //   username:localUser, 
      //   searchBy: req.params.searchBy, 
      //   searchHistory: req.params.search
      // })
      // console.log("search", search)
      console.log("\n  ## SOMETHING FOUND  ##  \n")
      // search.save(function(err, data){
      //   if (err) throw err
      //   console.log("Successfully Saved Search History")
      // })
      var error = new error_box(1, "Search Data Found !") 
      res.render('viewall', {error: error, data:data})
    }else{
      console.log("\n  ## NOTHING FOUND  ##  \n")
      var error = new error_box(3, "Nothing Found !") 
      res.render('viewall', {error: error, data:data})
    }
    // res.send('rand')
  })
})



const ObjectsToCsv = require('objects-to-csv')
// ############################# DOWNLOAD #########################
async function download(req, res, next){
  var loginUser = localStorage.getItem('loginUser')
  var entry = stockModel.find({username: loginUser})
  entry.exec(async function(err, data){
    if(err) throw err
    if(data.length && data){
      console.log('yess')
      // console.log(data)
      mod_data = []
      data.forEach(function(item, index){
        mod_data[index] = {
          index: index,
          _id: item._id,
          loggedUserId:item.username, 
          name: item.name, 
          imagePath: item.imagePath, 
          weblink: item.weblink, 
          email: item.email,
          password: item.password,
          password_type: item.password_type, 
          description: item.description, 
          date: item.date
        }
      })
      const csv = new ObjectsToCsv(mod_data)
      await csv.toDisk('./public/files/password_details.csv')
      // res.redirect('/viewall')
      next()
    }
  })
}

router.get('/download', checkUserLoggedIn, download,(req, res, next)=>{
  console.log("## [{ DOWNLOADED SUCCESSFULLY ! }] ##")
  res.download('./public/files/password_details.csv')
})







module.exports = router;

