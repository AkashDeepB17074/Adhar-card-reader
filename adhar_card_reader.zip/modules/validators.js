function checkUserLoggedIn(req, res, next){
    var getToken = localStorage.getItem('loginToken')
    try{
      var decoded = jwt.verify(getToken, 'loginTokenOfEmail')
    }catch(err){
      console.log("## [{ USER VALIDATION FAILED }] ##")
      return res.redirect('login')
    }
    next()
  }
  
  module.exports = checkUserLoggedIn;