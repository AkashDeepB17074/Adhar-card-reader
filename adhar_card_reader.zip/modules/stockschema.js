const mongoose = require('mongoose');
const bcrypt = require('bcryptjs')

// "## [{ STOCK}] ##"

//  Connection Setttings
// const url = 'mongodb+srv://kingdeep:kingdeep238@kingdeepcluster-7sjxx.mongodb.net/stockmanagement?retryWrites=true&w=majority'
var url = 'mongodb://localhost:27017/stockmanagement?readPreference=primary&appname=MongoDB%20Compass&ssl=false'
mongoose.connect(url, {useNewUrlParser: true, useCreateIndex: true})

const db = mongoose.connection;

db.on('error', console.error.bind(console, "## [{CONNECTION ERROR STOCK }] ##"))
db.on('connected', ()=>console.log("## [{ CONNECTED STOCK}] ##"))
db.on('disconnected', ()=>console.log("## [{ DISCONNECTED STOCK}] ##"))

var stockSchema = new mongoose.Schema({
    username:{
        type:String,
        required:true
    },
    name:{
        type:String
    },
    imagePath: {
        type:String
    }, 
    weblink: {
        type: String, 
        required: true
    },
    email: {
        type: String, 
        required: true
    },
    password: {
        type: String, 
        required: true
    },
    password_type:{
        type:String, 
        required: true
    },
    description: {
        type: String, 
    },
    date: {
        type: Date,
        default: Date.now()
    }
})

var stockModel = mongoose.model('stockTable', stockSchema);

module.exports = stockModel